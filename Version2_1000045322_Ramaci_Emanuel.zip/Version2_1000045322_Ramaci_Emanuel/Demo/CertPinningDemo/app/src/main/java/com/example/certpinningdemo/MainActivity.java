package com.example.certpinningdemo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import okhttp3.*;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private Button sendButton;
    private TextView resultTextView;

    private static final String GOOGLE_COM_PIN = "sha256/lQyW8MsNYz/rq2m5DKKbf9c+5ZD0xcszaujtAzh4Pk4=";
    private static final String HTTPBIN_ORG_PIN = "sha256/IFG+z/oQKXfpUYOHgWHy5axgkT9B01XSxwb2AHDyN34=";
    private static final String GOOGLE_HOSTNAME = "www.google.com";
    private static final String HTTPBIN_HOSTNAME = "httpbin.org";

    private static final String TAG = "CertPinningDemo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // UI layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        usernameEditText = new EditText(this);
        usernameEditText.setHint("Username");

        passwordEditText = new EditText(this);
        passwordEditText.setHint("Password");

        sendButton = new Button(this);
        sendButton.setText("Invia");

        resultTextView = new TextView(this);

        layout.addView(usernameEditText);
        layout.addView(passwordEditText);
        layout.addView(sendButton);
        layout.addView(resultTextView);

        setContentView(layout);

        // Certificate pinning
        CertificatePinner certificatePinner = new CertificatePinner.Builder()
                .add(HTTPBIN_HOSTNAME, HTTPBIN_ORG_PIN)
                .build();

        OkHttpClient client = new OkHttpClient.Builder()
                .certificatePinner(certificatePinner)
                .build();

        // On click POST
        sendButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            RequestBody formBody = new FormBody.Builder()
                    .add("username", username)
                    .add("password", password)
                    .build();

            Request request = new Request.Builder()
                    .url("https://" + HTTPBIN_HOSTNAME + "/post") // Se si vuole utilizzare www.google.com si deve togliere /post
                    .post(formBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Request failed: " + e.getMessage());
                    runOnUiThread(() -> resultTextView.setText("Request failed: " + e.getMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String result = response.isSuccessful()
                            ? "Success: " + response.code()
                            : "Failed: " + response.code();
                    Log.i(TAG, result);
                    runOnUiThread(() -> resultTextView.setText(result));
                }
            });
        });
    }
}
