package com.example.certpinningdemo;

import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.*;

import java.io.IOException;

public class MainActivityNoPinning extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private Button sendButton;
    private TextView resultTextView;

    private static final String TAG = "CertPinningDemo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Layout semplice con input utente
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        usernameEditText = new EditText(this);
        usernameEditText.setHint("Username");

        passwordEditText = new EditText(this);
        passwordEditText.setHint("Password");

        sendButton = new Button(this);
        sendButton.setText("Invia");

        resultTextView = new TextView(this);

        layout.addView(usernameEditText);
        layout.addView(passwordEditText);
        layout.addView(sendButton);
        layout.addView(resultTextView);
        setContentView(layout);

        // OkHttp senza pinning per test con Burp
        OkHttpClient client = new OkHttpClient();

        sendButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            RequestBody formBody = new FormBody.Builder()
                    .add("username", username)
                    .add("password", password)
                    .build();

            Request request = new Request.Builder()
                    .url("https://httpbin.org/post")
                    .post(formBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e(TAG, "Request failed: " + e.getMessage());
                    runOnUiThread(() -> resultTextView.setText("Errore: " + e.getMessage()));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String body = response.body().string();
                    runOnUiThread(() -> resultTextView.setText("Risposta:\n" + body));
                }
            });
        });
    }
}
