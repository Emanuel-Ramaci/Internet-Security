String hostname = "api.instagram.com";
/* Qui viene definita una variabile `hostname` con il valore `"api.instagram.com"`, che rappresenta l'indirizzo del server a cui verrà inviata la richiesta HTTP. */

CertificatePinner certificatePinner = new CertificatePinner.Builder()
    .add(hostname, "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")
    .build();
/* Il `CertificatePinner` è una funzionalità di OkHttp che serve per "pinning" del certificato SSL/TLS, cioè una misura di sicurezza che assicura che il client si connetta solo a server con un certificato specifico. In questo caso:

- `.add(hostname, "sha256/...")`: aggiunge una regola di pinning per il dominio `api.instagram.com`, associandolo a un certificato specificato tramite un hash SHA-256.
- L'hash `"sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="` è la rappresentazione codificata del certificato SSL che ci si aspetta dal server. */

OkHttpClient client = new OkHttpClient.Builder()
    .certificatePinner(certificatePinner)
    .build();
/* Qui viene creato un client OkHttp, che è l'oggetto principale per fare richieste HTTP. Viene configurato con il `CertificatePinner` creato nel passo precedente. Questo significa che ogni volta che il client farà una richiesta a `api.instagram.com`, il certificato SSL del server verrà verificato rispetto al pin configurato. */

Request request = new Request.Builder()
    .url("https://" + hostname + "/endpoint")
    .build();
/* Qui viene creata una richiesta HTTP. Il `Request.Builder()` viene utilizzato per costruire la richiesta con le seguenti informazioni:

- `.url("https://" + hostname + "/endpoint")`: definisce l'URL della richiesta, che in questo caso sarà `https://api.instagram.com/endpoint`. Il valore dell'`hostname` viene concatenato con `/endpoint` per formare l'URL completo. */

client.newCall(request).execute();
/* Infine, la richiesta viene eseguita tramite il metodo `newCall(request)`, che crea una chiamata HTTP basata sulla richiesta configurata. Il metodo `.execute()` invia la richiesta e restituisce la risposta del server in modo sincrono (cioè il codice si blocca finché non arriva una risposta dal server). */