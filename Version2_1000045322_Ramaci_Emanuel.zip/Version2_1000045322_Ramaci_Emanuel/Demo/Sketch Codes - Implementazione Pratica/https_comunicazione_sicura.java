URL url = new URL("https://i.instagram.com/api/v1/feed/");
/* Qui viene creata un'istanza dell'oggetto `URL` che rappresenta l'URL dell'API di Instagram. Questo URL punta a un endpoint che probabilmente restituisce il feed dell'utente (o un'altra risorsa). */

HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
/* A questo punto, viene aperta una connessione HTTPS verso l'URL appena creato. La classe `HttpsURLConnection` è una sottoclasse di `HttpURLConnection`, ma supporta le connessioni sicure tramite HTTPS. La connessione è rappresentata dall'oggetto `conn`. */

conn.setRequestMethod("GET");
/* Qui si specifica che il tipo di richiesta HTTP da inviare è un **GET**. Questo metodo è utilizzato per recuperare dati dal server, quindi la connessione invierà una richiesta di tipo "GET" all'endpoint dell'API di Instagram. */

InputStream in = new BufferedInputStream(conn.getInputStream());
/* In questo passaggio, viene creato un `InputStream` per leggere la risposta dalla connessione. Il metodo `getInputStream()` restituisce uno stream di input contenente i dati ricevuti dalla risposta del server (in questo caso, probabilmente il feed di Instagram).

L'oggetto `BufferedInputStream` serve per ottimizzare la lettura dei dati dalla rete, rendendola più efficiente. */